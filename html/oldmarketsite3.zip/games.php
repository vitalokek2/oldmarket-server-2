<?php
require_once 'android_versions.php';
$apps = json_decode(file_get_contents('http://45.137.188.68:5000/api/apps'), true);
$games = array_filter($apps, function($app) {
    return $app['is_game'];
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
  <meta http-equiv="Pragma" content="no-cache" />
  <meta http-equiv="Expires" content="0" />
  <title>OldMarket - Игры</title>
  <link rel="stylesheet" href="style.css">
</head>
  <div class="sticky-header-section">
    <header class="topnav">
      <div class="logo">
        <img src="logo.png" alt="Android Market Logo" width="260">
        <p id="visitorCount" style="color: rgb(224, 224, 224); font-size: 0.8em;"></p>
      </div>
    </header>
    <div class="search-container">
      <input type="text" id="searchInput" placeholder="Поиск" onkeyup="searchApps()">
    </div>
  </div>
<body>
  <div class="banner">
    <img src="banner.gif">
  </div>
    <script>
        function searchApps() {
          var query = document.getElementById('searchInput').value.toLowerCase();
          var apps = document.getElementsByClassName('app');
          
          for (var i = 0; i < apps.length; i++) {
              var appName = apps[i].getElementsByClassName('app-title')[0].textContent.toLowerCase();
              if (appName.indexOf(query) !== -1) {
                  apps[i].style.display = 'flex';
              } else {
                  apps[i].style.display = 'none';
              }
          }
      }

      function installApp(appId) {
          window.location.href = 'app.php?id=' + appId;
      }
    </script>

  <main>
    <section class="featured">
      <div class="app-list">
        <div class="add">
          <img src="apps.jpg" alt="Приложения" width="190" class="button-image" onclick="window.location.href='index.php'">
        </div>
        <?php foreach ($games as $game): ?>
        <div class="app" onclick="installApp(<?= $game['id'] ?>)">
          <img src="http://45.137.188.68:5000/html/apps/<?= $game['icon'] ?>" width="55">
          <div class="app-info">
            <span class="app-title"><?= htmlspecialchars($game['name']) ?></span><br>
            <span>Android <?= apiToAndroidVersion($game['api']) ?></span>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </section>
  </main>
  <div class="footer">
    <p>OldMarket &copy; 2025</p>
  </div>
</body>
</html>