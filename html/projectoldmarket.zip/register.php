<?php
require_once __DIR__ . '/auth_cookie.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$real_ip = real_ip();

/* Список запрещённых слов */
$bad_words = [
    'шалавы','блядина','оскорбление','блять','блядь','хуйня','шалава','хуйни','уебан',
    'негр','нигер','пидор','пидорас','пидорасина','хуесос','педик','педофил','педафил',
    'уебище','pidor','pidoras','fuck','жопа','пизда','пенис','хуй','говно',
    'путин','путiн','putin','зеленский','zelensky','сдохни','гандон','гитлер',
    'root','admin','administrator','oldmarket','олдмаркет','разраб','создатель',
    'anal','anall','анал','бомба','аллах','allah','террорист'
];

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    $errors = [];

    if (strlen($username) < 3 || strlen($username) > 15) {
        $errors[] = "Логин должен быть от 3 до 15 символов";
    }
    if (!preg_match('/^[a-zA-Z0-9]+$/', $username)) {
        $errors[] = "Логин может содержать только латинские буквы и цифры";
    }
    $uname_lower = strtolower($username);
    foreach ($bad_words as $bw) {
        if (strpos($uname_lower, $bw) !== false) {
            $errors[] = "Логин содержит запрещённые слова";
            break;
        }
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Некорректный email";
    }

    if (strlen($password) < 4) {
        $errors[] = "Пароль должен быть от 4 символов";
    }

    if (!empty($errors)) {
        $error = implode("<br>", $errors);
    } else {

        // 1) register
        $res = api_post_json('/api/register', [
            "username" => $username,
            "email"    => $email,
            "password" => $password
        ]);

        if ($res === false) {
            $error = "Ошибка соединения с сервером";
        } else {
            $j = json_decode($res, true);

            if (is_array($j) && !empty($j["user_id"])) {

                // 2) login сразу после регистрации (чтобы выставить cookies)
                $loginRes = api_post_json('/api/login', [
                    "username" => $username,
                    "password" => $password
                ]);

                if ($loginRes === false) {
                    $error = "Регистрация успешна, но вход не выполнен. Войдите вручную.";
                } else {
                    $lj = json_decode($loginRes, true);
                    if (is_array($lj) && !empty($lj["success"])) {
                        $uid   = (int)$lj["user_id"];
                        $uname = (string)$lj["username"];

                        // профиль (аватар/премиум)
                        $avatar = "default_avatar.png";
                        $is_premium = 0;

                        $profile_json = api_get('/api/user/' . $uid . '/profile');
                        if ($profile_json !== false) {
                            $p = json_decode($profile_json, true);
                            if (is_array($p) && empty($p["error"])) {
                                $avatar = $p["avatar"] ?? $avatar;
                                $is_premium = (int)($p["is_premium"] ?? 0);
                            }
                        }

                        auth_set_cookies($uid, $uname, $avatar, $is_premium);
                        header("Location: /index.php");
                        exit;
                    } else {
                        $error = "Регистрация успешна, но вход не выполнен. Войдите вручную.";
                    }
                }

            } else {
                $error = $j["error"] ?? "Ошибка регистрации";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Регистрация - OldMarket</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { background-image: url(background.jpg); background-repeat: repeat; background-size: 5%; color: white; font-family: Arial; }
        .register-form { max-width: 300px; margin: 50px auto; padding: 20px; background: #4444445e; }
        input { width: 100%; padding: 10px; margin: 5px 0; }
        button { width: 100%; padding: 10px; background: #a0b532; color: white; border: none; }
        .requirements { font-size: 12px; color: #aaa; margin-bottom: 5px; }
    </style>
</head>
<body>

<div class="register-form">
    <h2>Регистрация</h2>

    <?php if ($error): ?>
        <p style="color:red"><?= $error ?></p>
    <?php endif; ?>

    <div class="requirements">
        - Логин: 3–15 символов, только латиница и цифры<br>
        - Email корректный<br>
        - Пароль минимум 4 символа
    </div>

    <form method="POST">
        <input type="text" name="username" placeholder="Логин" required
               value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
        <input type="email" name="email" placeholder="Email" required
               value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>">
        <input type="password" name="password" placeholder="Пароль" required>
        <button type="submit">Зарегистрироваться</button>
    </form>

    <p>Уже есть аккаунт? <a href="login.php" style="color:#a0b532">Войти</a></p>
</div>

</body>
</html>