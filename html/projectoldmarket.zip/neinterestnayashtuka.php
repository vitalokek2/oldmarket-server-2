<?php
session_start();

/** НАСТРОЙКИ */
$API_BASE = "http://144.31.16.165:5000";
$ALLOWED_IPS = ["144.31.197.62"]; // <-- сюда свой IP (можно несколько)
$ADMIN_PASSWORD = "289111"; // <-- поставь сильный пароль

/** IP-ограничение */
$ip = $_SERVER['REMOTE_ADDR'];
if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
}
if (!in_array($ip, $ALLOWED_IPS, true)) {
    http_response_code(403);
    die("Access denied (IP)");
}

/** ВЫХОД */
if (isset($_GET['logout'])) {
    unset($_SESSION['admin_ok']);
    header("Location: admin.php");
    exit;
}

/** ЛОГИН */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $pwd = (string)($_POST['password'] ?? '');
    if (hash_equals($ADMIN_PASSWORD, $pwd)) {
        $_SESSION['admin_ok'] = 1;
        header("Location: neinterestnayashtuka.php");
        exit;
    } else {
        $login_error = "Неверный пароль";
    }
}

$admin_ok = !empty($_SESSION['admin_ok']);
if (!$admin_ok):
?>
<!doctype html>
<html lang="ru">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login</title>
<style>
body{font-family:Arial;background:#222;color:#fff;margin:0;padding:30px}
.box{max-width:420px;margin:0 auto;background:#333;padding:20px}
input{width:100%;padding:12px;font-size:16px;margin-top:10px}
button{padding:12px 16px;font-size:16px;margin-top:12px;width:100%;cursor:pointer}
.err{color:#ff8080;margin-top:10px}
</style>
</head>
<body>
<div class="box">
  <h2>Вход в админку</h2>
  <?php if (!empty($login_error)) echo "<div class='err'>".htmlspecialchars($login_error)."</div>"; ?>
  <form method="post">
    <input type="password" name="password" placeholder="Пароль" required>
    <button type="submit" name="login">Войти</button>
  </form>
</div>
</body>
</html>
<?php
exit;
endif;

/** helper: запрос к admin API */
function admin_api($method, $url, $password, $payload = null) {
    $headers = "Content-Type: application/json\r\n" .
               "X-Admin-Password: {$password}\r\n";
    $opts = [
        'http' => [
            'method' => $method,
            'header' => $headers,
            'ignore_errors' => true
        ]
    ];
    if ($payload !== null) {
        $opts['http']['content'] = json_encode($payload, JSON_UNESCAPED_UNICODE);
    }
    $ctx = stream_context_create($opts);
    $resp = @file_get_contents($url, false, $ctx);
    return $resp === false ? null : $resp;
}

/** УДАЛЕНИЕ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_review'])) {
    $rid = (int)$_POST['review_id'];
    $resp = admin_api("DELETE", "$API_BASE/api/admin/review/$rid", $ADMIN_PASSWORD);
    $action_msg = $resp ? $resp : "Ошибка соединения";
}

/** РЕДАКТИРОВАНИЕ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_review'])) {
    $rid = (int)$_POST['review_id'];
    $rating = (int)$_POST['rating'];
    $comment = (string)($_POST['comment'] ?? '');

    $payload = ["rating"=>$rating, "comment"=>$comment];
    $resp = admin_api("PUT", "$API_BASE/api/admin/review/$rid", $ADMIN_PASSWORD, $payload);
    $action_msg = $resp ? $resp : "Ошибка соединения";
}

/** СПИСОК ОТЗЫВОВ */
$app_id = isset($_GET['app_id']) ? (int)$_GET['app_id'] : 0;
$url = "$API_BASE/api/admin/reviews?limit=50";
if ($app_id > 0) $url .= "&app_id=".$app_id;

$listResp = admin_api("GET", $url, $ADMIN_PASSWORD);
$data = $listResp ? json_decode($listResp, true) : null;
$items = $data['items'] ?? [];
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>OldMarket Admin</title>
<style>
body{font-family:Arial;background:#222;color:#fff;margin:0;padding:20px}
a{color:#9ad}
.top{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
.card{background:#333;padding:12px;margin:12px 0}
input,textarea{width:100%;padding:10px;font-size:14px;margin:6px 0;border:0}
.row{display:flex;gap:10px;flex-wrap:wrap}
.small{font-size:12px;color:#bbb}
button{padding:10px 12px;border:0;cursor:pointer}
.btn-del{background:#b33;color:#fff}
.btn-save{background:#4a8;color:#fff}
.msg{background:#444;padding:10px;margin:10px 0}
</style>
</head>
<body>

<div class="top">
  <h2 style="margin:0;">OldMarket Admin</h2>
  <a href="admin.php?logout=1">Выйти</a>
</div>

<form method="get" class="top" style="margin-top:10px;">
  <label>Фильтр app_id:</label>
  <input type="number" name="app_id" value="<?= (int)$app_id ?>" style="max-width:160px;">
  <button type="submit">Показать</button>
</form>

<?php if (!empty($action_msg)): ?>
<div class="msg"><?= htmlspecialchars($action_msg) ?></div>
<?php endif; ?>

<?php if (!$data || isset($data['error'])): ?>
<div class="msg">Ошибка получения списка: <?= htmlspecialchars($listResp ?? "нет ответа") ?></div>
<?php else: ?>
<div class="small">Всего: <?= (int)$data['total'] ?> | Показано: <?= count($items) ?></div>
<?php foreach ($items as $r): ?>
<div class="card">
  <div class="small">
    review_id: <?= (int)$r['id'] ?> | app_id: <?= (int)$r['app_id'] ?> |
    user: <?= htmlspecialchars($r['username']) ?> (<?= (int)$r['user_id'] ?>) |
    <?= htmlspecialchars($r['created_at']) ?>
  </div>

  <form method="post">
    <input type="hidden" name="review_id" value="<?= (int)$r['id'] ?>">
    <div class="row">
      <div style="flex:0 0 120px;">
        <label>Rating (1-5)</label>
        <input type="number" name="rating" min="1" max="5" value="<?= (int)$r['rating'] ?>" required>
      </div>
      <div style="flex:1;">
        <label>Comment (до 300)</label>
        <textarea name="comment" maxlength="300" rows="3"><?= htmlspecialchars($r['comment']) ?></textarea>
      </div>
    </div>

    <div class="row">
      <button class="btn-save" type="submit" name="edit_review">Сохранить</button>
      <button class="btn-del" type="submit" name="delete_review" onclick="return confirm('Удалить отзыв?')">Удалить</button>
    </div>
  </form>
</div>
<?php endforeach; ?>
<?php endif; ?>

</body>
</html>