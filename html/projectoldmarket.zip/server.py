# server.py
import os
import re
import json
import requests
import threading
import time
from functools import wraps
from datetime import datetime, date, timedelta

from flask import Flask, jsonify, request, send_from_directory, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import func, text, case

from apps_data import apps

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///oldmarket.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'html/apps'
app.config['SECRET_KEY'] = 'goymhgklvcntk0ghiokphport'

BANNERS_DIR = os.environ.get("BANNERS_DIR", os.path.join("html", "banners"))
os.makedirs(BANNERS_DIR, exist_ok=True)

db = SQLAlchemy(app)

# --- Admin settings ---
ADMIN_PASSWORD = os.environ.get("289111", "289111")
ADMIN_ALLOWED_IPS = set((os.environ.get("OLDMARKET_ADMIN_ALLOWED_IPS", "144.31.197.62,144.31.16.165").split(",")))

# --- Telegram settings ---
TG_BOT_TOKEN = os.environ.get("TG_BOT_TOKEN", "8552714174:AAEn9mkVKznsBe7yj5DGTZQ_Mk8-4dUqUjQ").strip()
TG_ADMIN_ID = int(os.environ.get("TG_ADMIN_ID", "1184684448") or "0")
TG_WEBHOOK_SECRET = os.environ.get("TG_WEBHOOK_SECRET", "").strip()

# ==============================
#           МОДЕЛИ БД
# ==============================

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login_ip = db.Column(db.String(50), nullable=True)


class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_id = db.Column(db.Integer, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)


class ReviewReaction(db.Model):
    __tablename__ = 'review_reaction'
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, db.ForeignKey('review.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    value = db.Column(db.Integer, nullable=False)  # +1 like, -1 dislike
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    __table_args__ = (
        db.UniqueConstraint('review_id', 'user_id', name='uq_review_reaction_review_user'),
    )

class ReactionRateLimit(db.Model):
    __tablename__ = 'reaction_rate_limit'
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, nullable=False, index=True)
    ip = db.Column(db.String(50), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class ReviewComment(db.Model):
    __tablename__ = 'review_comment'
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, db.ForeignKey('review.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    text = db.Column(db.String(300), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class Download(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_id = db.Column(db.Integer, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True, index=True)
    downloaded_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class DownloadIP(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    app_id = db.Column(db.Integer, nullable=False, index=True)
    ip = db.Column(db.String(50), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('app_id', 'ip', name='uq_download_ip'),
    )

class UserProfile(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), unique=True, nullable=False, index=True)
    avatar = db.Column(db.String(100), default='avatar1.png')
    description = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    is_premium = db.Column(db.Integer, default=0)
    premium_until = db.Column(db.DateTime, nullable=True)

class RegistrationIP(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(50), nullable=False, index=True)
    day = db.Column(db.Date, nullable=False, index=True)
    count = db.Column(db.Integer, default=0)

    __table_args__ = (
        db.UniqueConstraint('ip', 'day', name='uq_reg_ip_day'),
    )

class LoginAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(50), nullable=False, index=True)
    username = db.Column(db.String(80), nullable=True, index=True)
    success = db.Column(db.Boolean, default=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class BlockedIP(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(50), nullable=False, unique=True)
    reason = db.Column(db.String(200), nullable=False)
    until = db.Column(db.DateTime, nullable=False)

class SecurityEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(50), nullable=True, index=True)
    user_id = db.Column(db.Integer, nullable=True, index=True)
    event_type = db.Column(db.String(50), nullable=False, index=True)
    details = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class CommentRateLimit(db.Model):
    __tablename__ = 'comment_rate_limit'
    id = db.Column(db.Integer, primary_key=True)
    ip = db.Column(db.String(50), nullable=False, index=True)
    user_id = db.Column(db.Integer, nullable=True, index=True)
    review_id = db.Column(db.Integer, nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

class ReactionIP(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, nullable=False, index=True)
    ip = db.Column(db.String(50), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('review_id', 'ip', name='uq_reaction_ip_review'),
    )

# ====== NEW: Telegram moderators + reports ======

class TgModerator(db.Model):
    __tablename__ = 'tg_moderator'
    id = db.Column(db.Integer, primary_key=True)
    tg_user_id = db.Column(db.Integer, nullable=False, index=True)
    app_id = db.Column(db.Integer, nullable=True, index=True)  # NULL = глобальный модератор
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    __table_args__ = (
        db.UniqueConstraint('tg_user_id', 'app_id', name='uq_tg_moderator_user_app'),
    )

class Report(db.Model):
    __tablename__ = 'report'
    id = db.Column(db.Integer, primary_key=True)
    review_id = db.Column(db.Integer, nullable=False, index=True)
    reporter_user_id = db.Column(db.Integer, nullable=False, index=True)
    reason = db.Column(db.String(200), nullable=True)
    status = db.Column(db.String(20), default='new', index=True)  # new/ignored/resolved
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    handled_by_tg = db.Column(db.Integer, nullable=True)
    handled_action = db.Column(db.String(20), nullable=True)  # delete/ban/ignore


AVAILABLE_AVATARS = [
    'avatar1.png', 'avatar2.png', 'avatar3.png', 'avatar4.png', 'avatar4.gif', 'avatar5.gif',
    'avatar6.gif', 'avatar7.gif', 'avatar11.gif', 'avatar12.gif', 'avatar13.gif', 'avatar14.gif',
    'avatar8.gif', 'avatar9.gif', 'avatar10.gif', 'avatar15.gif', 'avatar16.gif', 'avatar17.gif',
]

BAD_WORDS = [
    'шалавы', 'блядина', 'оскорбление', 'блять', 'блядь', 'хуйня', 'шалава', 'хуйни', 'уебан',
    'негр', 'нигер', 'пидор', 'пидорас', 'пидорасина', 'хуесос', 'педик', 'педофил', 'педафил',
    'уебище', 'pidor', 'pidoras', 'fuck', 'жопа', 'пизда', 'пенис', 'хуй', 'говно', 'путин',
    'путiн', 'putin', 'зеленский', 'zelensky', 'сдохни', 'гандон', 'гитлер', 'root', 'admin',
    'Administrator', 'oldmarket', 'олдмаркет', 'разраб', 'создатель', 'anal', 'anall', 'анал',
    'бомба', 'аллах', 'allah', 'террорист'
]

# ==============================
#       ВСПОМОГАТЕЛЬНЫЕ
# ==============================

def get_real_ip():
    xff = request.headers.get('X-Forwarded-For')
    if xff:
        return xff.split(',')[0].strip()
    return request.headers.get('CF-Connecting-IP') or \
           request.headers.get('X-Real-IP') or \
           request.remote_addr

def contains_bad_words(text: str) -> bool:
    if not text:
        return False
    t = text.lower()
    for w in BAD_WORDS:
        if w in t:
            return True
    return False

def is_ip_blocked(ip: str) -> bool:
    if not ip:
        return False
    block = BlockedIP.query.filter_by(ip=ip).first()
    if not block:
        return False
    if block.until <= datetime.utcnow():
        db.session.delete(block)
        db.session.commit()
        return False
    return True

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        ip = get_real_ip()
        if ip not in ADMIN_ALLOWED_IPS:
            return jsonify({"error": "Admin access denied (ip)"}), 403

        pwd = request.headers.get("X-Admin-Password", "")
        if not pwd or pwd != ADMIN_PASSWORD:
            return jsonify({"error": "Admin auth failed"}), 401

        return fn(*args, **kwargs)
    return wrapper

def log_security(event_type: str, ip: str = None, user_id: int = None, details: str = None):
    ev = SecurityEvent(ip=ip, user_id=user_id, event_type=event_type, details=details)
    db.session.add(ev)
    db.session.commit()
    print(f"[SECURITY] {datetime.utcnow().isoformat()} [{event_type}] ip={ip} user_id={user_id} {details or ''}")

def ban_ip(ip: str, reason: str, hours: int = 1):
    if not ip:
        return
    until = datetime.utcnow() + timedelta(hours=hours)
    blk = BlockedIP.query.filter_by(ip=ip).first()
    if not blk:
        blk = BlockedIP(ip=ip, reason=reason, until=until)
        db.session.add(blk)
    else:
        blk.until = until
        blk.reason = reason
    db.session.commit()
    log_security("ip_banned", ip=ip, details=f"{reason}, until={until.isoformat()}")

def check_registration_rate_limit(ip: str, limit_per_day: int = 3) -> bool:
    today = date.today()
    rec = RegistrationIP.query.filter_by(ip=ip, day=today).first()
    if rec and rec.count >= limit_per_day:
        return False
    return True

def increment_registration_ip(ip: str):
    today = date.today()
    rec = RegistrationIP.query.filter_by(ip=ip, day=today).first()
    if not rec:
        rec = RegistrationIP(ip=ip, day=today, count=1)
        db.session.add(rec)
    else:
        rec.count += 1
    db.session.commit()

def record_login_attempt(ip: str, username: str, success: bool):
    att = LoginAttempt(ip=ip, username=username, success=success)
    db.session.add(att)
    db.session.commit()

def check_login_bruteforce(ip: str, window_minutes: int = 15, max_failures: int = 5) -> bool:
    cutoff = datetime.utcnow() - timedelta(minutes=window_minutes)
    fails = LoginAttempt.query.filter(
        LoginAttempt.ip == ip,
        LoginAttempt.created_at >= cutoff,
        LoginAttempt.success == False
    ).count()
    return fails >= max_failures

def build_apps_with_stats(apps_list):
    app_ids = [a["id"] for a in apps_list]
    if not app_ids:
        return []

    reviews_rows = db.session.query(
        Review.app_id.label("app_id"),
        func.avg(Review.rating).label("avg_rating"),
        func.count(Review.id).label("review_count"),
    ).filter(
        Review.app_id.in_(app_ids)
    ).group_by(
        Review.app_id
    ).all()

    reviews_map = {
        r.app_id: (float(r.avg_rating) if r.avg_rating is not None else 0.0, int(r.review_count))
        for r in reviews_rows
    }

    downloads_rows = db.session.query(
        Download.app_id.label("app_id"),
        func.count(Download.id).label("downloads"),
    ).filter(
        Download.app_id.in_(app_ids)
    ).group_by(
        Download.app_id
    ).all()

    downloads_map = {d.app_id: int(d.downloads) for d in downloads_rows}

    out = []
    for a in apps_list:
        avg_rating, review_count = reviews_map.get(a["id"], (0.0, 0))
        downloads = downloads_map.get(a["id"], 0)
        out.append({
            **a,
            "rating": round(avg_rating, 1),
            "downloads": downloads,
            "review_count": review_count
        })
    return out



def _norm(s: str) -> str:
    s = (s or "").lower()
    s = re.sub(r"\s+", " ", s).strip()
    return s

def _app_search_haystack(a: dict) -> str:
    parts = []
    for k in ("name", "title", "app_name", "package", "developer", "author", "category", "description", "desc"):
        v = a.get(k)
        if isinstance(v, str) and v.strip():
            parts.append(v)

    for k in ("tags", "genres"):
        v = a.get(k)
        if isinstance(v, list):
            parts.extend([str(x) for x in v if x is not None])

    return _norm(" ".join(parts))

def _search_score(a: dict, q_terms: list[str]) -> int:
    name = _norm(a.get("name") or a.get("title") or a.get("app_name") or "")
    hay = _app_search_haystack(a)

    score = 0
    for t in q_terms:
        if not t:
            continue
        if t in name:
            score += 10
            if name.startswith(t):
                score += 5
        if t in hay:
            score += 3
    return score

# -------- Telegram helpers --------

def tg_api(method: str, payload: dict):
    if not TG_BOT_TOKEN:
        return None
    url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/{method}"
    try:
        r = requests.post(url, json=payload, timeout=10)
        return r.json()
    except Exception as e:
        print("TG API error:", e)
        return None

def tg_send_message(chat_id: int, text: str, reply_markup: dict = None):
    payload = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup
    return tg_api("sendMessage", payload)

def tg_edit_message(chat_id: int, message_id: int, text: str, reply_markup: dict = None):
    payload = {
        "chat_id": chat_id,
        "message_id": message_id,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True
    }
    if reply_markup is not None:
        payload["reply_markup"] = reply_markup
    return tg_api("editMessageText", payload)

def tg_answer_callback(callback_query_id: str, text: str = ""):
    payload = {"callback_query_id": callback_query_id}
    if text:
        payload["text"] = text
        payload["show_alert"] = False
    return tg_api("answerCallbackQuery", payload)

def _trim200(s: str) -> str:
    s = (s or "").strip()
    if len(s) <= 200:
        return s
    return s[:200] + "…"

def delete_review_full(review_id: int):
    ReviewReaction.query.filter_by(review_id=review_id).delete()
    ReviewComment.query.filter_by(review_id=review_id).delete()
    ReactionRateLimit.query.filter_by(review_id=review_id).delete()
    CommentRateLimit.query.filter_by(review_id=review_id).delete()
    ReactionIP.query.filter_by(review_id=review_id).delete()
    Review.query.filter_by(id=review_id).delete()
    db.session.commit()

def ban_user_and_purge(user_id: int):
    reviews = Review.query.filter_by(user_id=user_id).all()
    review_ids = [r.id for r in reviews]

    if review_ids:
        ReviewReaction.query.filter(ReviewReaction.review_id.in_(review_ids)).delete(synchronize_session=False)
        ReviewComment.query.filter(ReviewComment.review_id.in_(review_ids)).delete(synchronize_session=False)
        ReactionRateLimit.query.filter(ReactionRateLimit.review_id.in_(review_ids)).delete(synchronize_session=False)
        CommentRateLimit.query.filter(CommentRateLimit.review_id.in_(review_ids)).delete(synchronize_session=False)
        ReactionIP.query.filter(ReactionIP.review_id.in_(review_ids)).delete(synchronize_session=False)

    Review.query.filter_by(user_id=user_id).delete()

    ReviewReaction.query.filter_by(user_id=user_id).delete()
    ReviewComment.query.filter_by(user_id=user_id).delete()

    UserProfile.query.filter_by(user_id=user_id).delete()
    Download.query.filter_by(user_id=user_id).delete()
    User.query.filter_by(id=user_id).delete()
    db.session.commit()

# CORS + кэш
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')

    if request.path.startswith('/html/'):
        response.headers['Cache-Control'] = 'public, max-age=86400'
    return response

# ==============================
#           API ПРИЛОЖЕНИЙ
# ==============================

@app.route('/api/app/<int:app_id>', methods=['GET', 'OPTIONS'])
def api_app(app_id):
    if request.method == 'OPTIONS':
        return '', 200

    app_item = next((a for a in apps if a["id"] == app_id), None)
    if not app_item:
        return jsonify({"error": "App not found"}), 404

    avg_rating, review_count = db.session.query(
        func.avg(Review.rating),
        func.count(Review.id)
    ).filter(Review.app_id == app_id).one()

    downloads = db.session.query(func.count(Download.id)) \
                          .filter(Download.app_id == app_id) \
                          .scalar() or 0

    return jsonify({
        **app_item,
        "rating": round(float(avg_rating or 0.0), 1),
        "downloads": int(downloads),
        "review_count": int(review_count or 0)
    })

@app.route('/api/apps', methods=['GET', 'OPTIONS'])
def api_apps():
    if request.method == 'OPTIONS':
        return '', 200

    is_game = request.args.get('is_game')
    limit = request.args.get('limit', type=int)
    offset = request.args.get('offset', type=int, default=0)

    filtered = apps
    if is_game is not None:
        want_game = str(is_game).lower() in ('1', 'true', 'yes')
        filtered = [a for a in apps if bool(a.get('is_game')) == want_game]

    if limit is not None and limit > 0:
        filtered = filtered[offset:offset + limit]

    return jsonify(build_apps_with_stats(filtered))


@app.route('/api/apps/search', methods=['GET', 'OPTIONS'])
def api_apps_search():
    if request.method == 'OPTIONS':
        return '', 200

    q = (request.args.get('q') or '').strip()
    is_game = request.args.get('is_game')
    limit = request.args.get('limit', type=int)
    offset = request.args.get('offset', type=int, default=0)

    filtered = apps

    if is_game is not None:
        want_game = str(is_game).lower() in ('1', 'true', 'yes')
        filtered = [a for a in filtered if bool(a.get('is_game')) == want_game]

    if q:
        qn = _norm(q)
        terms = [t for t in qn.split(' ') if t]

        scored = []
        for a in filtered:
            hay = _app_search_haystack(a)
            if all(t in hay for t in terms):
                scored.append((a, _search_score(a, terms)))

        scored.sort(key=lambda x: (x[1], x[0].get('id', 0)), reverse=True)
        filtered = [a for a, _ in scored]

    if limit is not None and limit > 0:
        filtered = filtered[offset:offset + limit]

    return jsonify(build_apps_with_stats(filtered))


@app.route('/api/top-apps', methods=['GET', 'OPTIONS'])
def top_apps():
    if request.method == 'OPTIONS':
        return '', 200
    non_games = [a for a in apps if not a.get('is_game')]
    with_stats = build_apps_with_stats(non_games)
    top_list = sorted(with_stats, key=lambda x: x['downloads'], reverse=True)[:10]
    return jsonify(top_list)

@app.route('/api/top-games', methods=['GET', 'OPTIONS'])
def top_games():
    if request.method == 'OPTIONS':
        return '', 200
    games = [a for a in apps if a.get('is_game')]
    with_stats = build_apps_with_stats(games)
    top_list = sorted(with_stats, key=lambda x: x['downloads'], reverse=True)[:10]
    return jsonify(top_list)

@app.route("/html/banners/<path:filename>")
def banners_download(filename):
    return send_from_directory(BANNERS_DIR, filename)

@app.route("/api/banners")
def api_banners():
    link_map = {
        "banner1.jpg": "",
        "banner2.jpg": "https://t.me/apksherr",
        "banner3.jpg": "https://t.me/oldmarketsupport_bot",
        "banner4.jpg": "https://yoomoney.ru/to/4100117591116914",
        "banner11.jpg": "https://t.me/sportanotw1n",
        "banner12.jpg": "https://t.me/assizdns",
    }

    items = []
    for fn in sorted(os.listdir(BANNERS_DIR)):
        low = fn.lower()
        if not (low.endswith(".jpg") or low.endswith(".jpeg") or low.endswith(".png") or low.endswith(".webp")):
            continue
        items.append({
            "image": fn,
            "url": link_map.get(fn, "")
        })
    return items

@app.route('/api/app/<int:app_id>/screenshots', methods=['GET', 'OPTIONS'])
def get_app_screenshots(app_id):
    if request.method == 'OPTIONS':
        return '', 200

    app_item = next((a for a in apps if a["id"] == app_id), None)
    if not app_item:
        return jsonify({"error": "App not found"}), 404
    return jsonify(app_item.get("screenshots", []))

@app.route('/html/screenshots/<path:filename>')
def serve_screenshots(filename):
    return send_from_directory('html/screenshots', filename)

@app.route('/api/app/<int:app_id>/versions', methods=['GET', 'OPTIONS'])
def get_app_versions(app_id):
    if request.method == 'OPTIONS':
        return '', 200

    app_item = next((a for a in apps if a["id"] == app_id), None)
    if not app_item:
        return jsonify({"error": "App not found"}), 404
    return jsonify(app_item.get("versions", []))

# ==============================
#       СКАЧИВАНИЕ
# ==============================

@app.route('/api/download/<int:app_id>/<version>', methods=['GET', 'OPTIONS'])
def download_app_version(app_id, version):
    if request.method == 'OPTIONS':
        return '', 200

    try:
        app_data = next((a for a in apps if a["id"] == app_id), None)
        if not app_data:
            return jsonify({"error": "App not found"}), 404

        version_data = next((v for v in app_data.get("versions", []) if v["version"] == version), None)
        if not version_data:
            return jsonify({"error": "Version not found"}), 404

        user_id = request.args.get('user_id')
        user_ip = get_real_ip()

        if is_ip_blocked(user_ip):
            log_security("download_blocked_ip", ip=user_ip, details=f"app_id={app_id}")
            return jsonify({"error": "IP blocked"}), 429

        ip_exists = DownloadIP.query.filter_by(app_id=app_id, ip=user_ip).first()
        if not ip_exists:
            db.session.add(DownloadIP(app_id=app_id, ip=user_ip))
            db.session.add(Download(app_id=app_id, user_id=user_id))
            db.session.commit()
        else:
            log_security("download_duplicate_ip", ip=user_ip, details=f"app_id={app_id}")

        return send_from_directory(app.config['UPLOAD_FOLDER'], version_data["apk_file"], as_attachment=True)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/download/<int:app_id>', methods=['GET', 'OPTIONS'])
def download_app(app_id):
    if request.method == 'OPTIONS':
        return '', 200

    try:
        user_id = request.args.get('user_id')
        app_data = next((a for a in apps if a["id"] == app_id), None)
        if not app_data:
            return jsonify({"error": "App not found"}), 404

        user_ip = get_real_ip()
        if is_ip_blocked(user_ip):
            log_security("download_blocked_ip", ip=user_ip, details=f"app_id={app_id}")
            return jsonify({"error": "IP blocked"}), 429

        ip_exists = DownloadIP.query.filter_by(app_id=app_id, ip=user_ip).first()
        if not ip_exists:
            db.session.add(DownloadIP(app_id=app_id, ip=user_ip))
            db.session.add(Download(app_id=app_id, user_id=user_id))
            db.session.commit()
        else:
            log_security("download_duplicate_ip", ip=user_ip, details=f"app_id={app_id}")

        return send_from_directory(app.config['UPLOAD_FOLDER'], app_data["apk_file"], as_attachment=True)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ==============================
#             ОТЗЫВЫ
# ==============================

@app.route('/api/app/<int:app_id>/reviews', methods=['GET', 'OPTIONS'])
def get_reviews(app_id):
    if request.method == 'OPTIONS':
        return '', 200

    try:
        viewer_id = request.args.get('viewer_id', type=int)

        reviews = (Review.query
                   .filter_by(app_id=app_id)
                   .order_by(Review.created_at.desc())
                   .all())

        if not reviews:
            return jsonify([])

        review_ids = [r.id for r in reviews]
        user_ids = list({r.user_id for r in reviews})

        users = User.query.filter(User.id.in_(user_ids)).all()
        users_map = {u.id: u for u in users}

        profiles = UserProfile.query.filter(UserProfile.user_id.in_(user_ids)).all()
        profiles_map = {p.user_id: p for p in profiles}

        react_rows = (db.session.query(
                        ReviewReaction.review_id.label('rid'),
                        func.sum(case((ReviewReaction.value == 1, 1), else_=0)).label('likes'),
                        func.sum(case((ReviewReaction.value == -1, 1), else_=0)).label('dislikes'),
                      )
                      .filter(ReviewReaction.review_id.in_(review_ids))
                      .group_by(ReviewReaction.review_id)
                      .all())
        reacts_map = {row.rid: row for row in react_rows}

        viewer_map = {}
        if viewer_id:
            vr = (ReviewReaction.query
                  .filter(ReviewReaction.user_id == viewer_id,
                          ReviewReaction.review_id.in_(review_ids))
                  .all())
            viewer_map = {x.review_id: x.value for x in vr}

        c_rows = (db.session.query(
                    ReviewComment.review_id.label('rid'),
                    func.count(ReviewComment.id).label('cnt')
                  )
                  .filter(ReviewComment.review_id.in_(review_ids))
                  .group_by(ReviewComment.review_id)
                  .all())
        comments_cnt_map = {row.rid: row.cnt for row in c_rows}

        result = []
        for r in reviews:
            u = users_map.get(r.user_id)
            p = profiles_map.get(r.user_id)

            rx = reacts_map.get(r.id)
            likes = int(rx.likes) if rx else 0
            dislikes = int(rx.dislikes) if rx else 0

            result.append({
                "id": r.id,
                "user_id": r.user_id,
                "username": u.username if u else "Unknown",
                "avatar": (p.avatar if p else "default_avatar.png"),
                "rating": r.rating,
                "comment": r.comment,
                "created_at": r.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                "likes": likes,
                "dislikes": dislikes,
                "user_reaction": int(viewer_map.get(r.id, 0)) if viewer_id else 0,
                "comments_count": int(comments_cnt_map.get(r.id, 0)),
                "is_premium": int(p.is_premium) if p else 0,
            })

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/app/<int:app_id>/review', methods=['POST', 'OPTIONS'])
def add_review(app_id):
    if request.method == 'OPTIONS':
        return '', 200

    try:
        data = request.get_json() or {}

        ip = data.get("ip") or request.headers.get("X-Forwarded-For") or request.remote_addr
        if ip and "," in ip:
            ip = ip.split(",")[0].strip()

        if is_ip_blocked(ip):
            log_security("review_blocked_ip", ip=ip, details=f"app_id={app_id}")
            return jsonify({"error": "IP blocked"}), 429

        user_id = data.get('user_id')
        if not user_id:
            return jsonify({"error": "User ID is required"}), 401

        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 401

        rating = data.get('rating')
        if not rating:
            return jsonify({"error": "Rating is required"}), 400

        app_exists = any(a['id'] == app_id for a in apps)
        if not app_exists:
            return jsonify({"error": "App not found"}), 404

        existing_review = Review.query.filter_by(app_id=app_id, user_id=user_id).first()
        if existing_review:
            return jsonify({"error": "You have already reviewed this app"}), 400

        review = Review(
            app_id=app_id,
            user_id=user_id,
            rating=rating,
            comment=data.get('comment', '')
        )
        db.session.add(review)
        db.session.commit()

        return jsonify({"success": True, "message": "Review added successfully"}), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/review/<int:review_id>/reaction', methods=['POST', 'OPTIONS'])
def set_review_reaction(review_id):
    if request.method == 'OPTIONS':
        return '', 200
    try:
        ip = get_real_ip()
        if is_ip_blocked(ip):
            return jsonify({"error": "IP blocked"}), 429

        data = request.get_json() or {}
        user_id = data.get('user_id')
        value = int(data.get('value', 0))

        if not user_id:
            return jsonify({"error": "User ID is required"}), 401
        if value not in (-1, 0, 1):
            return jsonify({"error": "Invalid value"}), 400

        review = Review.query.get(review_id)
        if not review:
            return jsonify({"error": "Review not found"}), 404

        now = datetime.utcnow()
        cutoff = now - timedelta(seconds=60)
        ip_events = ReactionRateLimit.query.filter(
            ReactionRateLimit.ip == ip,
            ReactionRateLimit.created_at >= cutoff
        ).count()

        if ip_events >= 20:
            ban_ip(ip, reason="reaction_rate_limit", hours=1)
            return jsonify({"error": "Too many reactions, IP temporarily blocked"}), 429

        db.session.add(ReactionRateLimit(ip=ip, review_id=review_id))
        db.session.commit()

        ip_exists = ReactionIP.query.filter_by(review_id=review_id, ip=ip).first()
        if ip_exists:
            return jsonify({"error": "Only one reaction per IP for this review"}), 429

        if value == 0:
            return jsonify({"error": "Cannot remove reaction"}), 400

        existing = ReviewReaction.query.filter_by(review_id=review_id, user_id=user_id).first()
        if existing:
            existing.value = value
        else:
            db.session.add(ReviewReaction(review_id=review_id, user_id=user_id, value=value))

        db.session.add(ReactionIP(review_id=review_id, ip=ip))
        db.session.commit()

        likes = ReviewReaction.query.filter_by(review_id=review_id, value=1).count()
        dislikes = ReviewReaction.query.filter_by(review_id=review_id, value=-1).count()

        return jsonify({"success": True, "likes": likes, "dislikes": dislikes, "user_reaction": value})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/review/<int:review_id>/comments', methods=['GET', 'OPTIONS'])
def list_review_comments(review_id):
    if request.method == 'OPTIONS':
        return '', 200
    try:
        review = Review.query.get(review_id)
        if not review:
            return jsonify({"error": "Review not found"}), 404

        rows = (db.session.query(
                    ReviewComment,
                    User.username,
                    UserProfile.avatar
                )
                .join(User, User.id == ReviewComment.user_id)
                .outerjoin(UserProfile, UserProfile.user_id == ReviewComment.user_id)
                .filter(ReviewComment.review_id == review_id)
                .order_by(ReviewComment.created_at.asc())
                .all())

        out = []
        for c, username, avatar in rows:
            out.append({
                "id": c.id,
                "user_id": c.user_id,
                "username": username or "Unknown",
                "avatar": avatar or "default_avatar.png",
                "text": c.text,
                "created_at": c.created_at.strftime('%Y-%m-%d %H:%M:%S')
            })

        return jsonify(out)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/review/<int:review_id>/comment', methods=['POST', 'OPTIONS'])
def add_review_comment(review_id):
    if request.method == 'OPTIONS':
        return '', 200
    try:
        ip = get_real_ip()
        if is_ip_blocked(ip):
            return jsonify({"error": "IP blocked"}), 429

        data = request.get_json() or {}
        user_id = data.get('user_id')
        text_ = (data.get('text') or '').strip()

        if not user_id:
            return jsonify({"error": "User ID is required"}), 401
        if not text_:
            return jsonify({"error": "Text is required"}), 400
        if len(text_) > 300:
            return jsonify({"error": "Comment too long (max 300)"}), 400

        review = Review.query.get(review_id)
        if not review:
            return jsonify({"error": "Review not found"}), 404

        allowed_re = r'^[a-zA-Zа-яА-ЯёЁ0-9\s!()\?.,:;\"\'\+\-]+$'
        if not re.match(allowed_re, text_):
            return jsonify({"error": "Invalid characters"}), 400

        now = datetime.utcnow()

        cutoff = now - timedelta(minutes=2)
        cnt_ip = CommentRateLimit.query.filter(
            CommentRateLimit.ip == ip,
            CommentRateLimit.created_at >= cutoff
        ).count()
        if cnt_ip >= 10:
            return jsonify({"error": "Слишком много комментариев. Попробуйте позже."}), 429

        cutoff2 = now - timedelta(seconds=15)
        cnt_pair = CommentRateLimit.query.filter(
            CommentRateLimit.user_id == int(user_id),
            CommentRateLimit.review_id == review_id,
            CommentRateLimit.created_at >= cutoff2
        ).count()
        if cnt_pair >= 1:
            return jsonify({"error": "Слишком часто. Подождите 15 секунд."}), 429

        db.session.add(CommentRateLimit(ip=ip, user_id=int(user_id), review_id=review_id))
        db.session.commit()

        db.session.add(ReviewComment(review_id=review_id, user_id=user_id, text=text_))
        db.session.commit()

        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ===== NEW: Report review -> Telegram =====

@app.route('/api/review/<int:review_id>/report', methods=['POST', 'OPTIONS'])
def report_review(review_id):
    if request.method == 'OPTIONS':
        return '', 200
    try:
        data = request.get_json() or {}
        user_id = data.get('user_id')

        if not user_id:
            return jsonify({"error": "User ID is required"}), 401

        reporter = User.query.get(int(user_id))
        if not reporter:
            return jsonify({"error": "User not found"}), 401

        review = Review.query.get(review_id)
        if not review:
            return jsonify({"error": "Review not found"}), 404

        # антиспам: 1 жалоба на отзыв от пользователя за 24 часа
        cutoff = datetime.utcnow() - timedelta(hours=24)
        exists = Report.query.filter(
            Report.review_id == review_id,
            Report.reporter_user_id == int(user_id),
            Report.created_at >= cutoff
        ).first()
        if exists:
            return jsonify({"error": "You have already reported this review recently"}), 429

        reason = (data.get("reason") or "").strip()
        if reason and len(reason) > 200:
            reason = reason[:200]

        rep = Report(review_id=review_id, reporter_user_id=int(user_id), reason=reason or None)
        db.session.add(rep)
        db.session.commit()

        author = User.query.get(review.user_id)
        app_id = int(review.app_id)

        review_text = _trim200(review.comment or "")
        author_name = author.username if author else f"User#{review.user_id}"

        text_msg = (
            f"🚨 <b>ЖАЛОБА НА ОТЗЫВ</b>\n"
            f"<b>Приложение:</b> #{app_id}\n"
            f"<b>ID отзыва:</b> {review.id}\n"
            f"<b>Кто пожаловался:</b> {reporter.username} (user_id={reporter.id})\n"
            f"<b>Автор отзыва:</b> {author_name} (user_id={review.user_id})\n"
            f"<b>Рейтинг:</b> {review.rating}\n"
            f"<b>Текст:</b> {review_text or '(без текста)'}\n"
        )
        if rep.reason:
            text_msg += f"<b>Причина:</b> {rep.reason}\n"

        kb = {
            "inline_keyboard": [
                [
                    {"text": "🗑 Удалить отзыв", "callback_data": f"rep|{rep.id}|del"},
                    {"text": "⛔ Забанить пользователя", "callback_data": f"rep|{rep.id}|banq"},
                ],
                [
                    {"text": "✅ Игнорировать", "callback_data": f"rep|{rep.id}|ign"}
                ]
            ]
        }

        # модераторы: глобальные + для app_id
        mods = TgModerator.query.filter(
            (TgModerator.app_id == None) | (TgModerator.app_id == app_id)
        ).all()

        if not mods:
            if TG_ADMIN_ID:
                tg_send_message(TG_ADMIN_ID, text_msg, kb)
        else:
            sent_to = set()
            for m in mods:
                if m.tg_user_id in sent_to:
                    continue
                sent_to.add(m.tg_user_id)
                tg_send_message(m.tg_user_id, text_msg, kb)

        return jsonify({"success": True})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ==============================
#         РЕГИСТРАЦИЯ / ЛОГИН
# ==============================

@app.route('/api/register', methods=['POST', 'OPTIONS'])
def register():
    if request.method == 'OPTIONS':
        return '', 200

    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400

        username = (data.get('username') or '').strip()
        email = (data.get('email') or '').strip()
        password = (data.get('password') or '')

        ip = get_real_ip()
        if is_ip_blocked(ip):
            log_security("register_blocked_ip", ip=ip)
            return jsonify({"error": "IP blocked"}), 429

        if not check_registration_rate_limit(ip):
            log_security("register_rate_limit", ip=ip, details="too many accounts from this IP today")
            return jsonify({"error": "Too many registrations from this IP today"}), 429

        if not username or not email or not password:
            return jsonify({"error": "All fields are required"}), 400

        if len(username) < 3 or len(username) > 32:
            return jsonify({"error": "Username must be between 3 and 32 chars"}), 400

        if not re.match(r'^[a-zA-Z0-9_\-]+$', username):
            return jsonify({"error": "Username contains invalid characters"}), 400

        if len(password) < 6:
            return jsonify({"error": "Password must be at least 6 characters"}), 400

        if not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
            return jsonify({"error": "Invalid email"}), 400

        if User.query.filter_by(username=username).first():
            return jsonify({"error": "Username already exists"}), 400

        if User.query.filter_by(email=email).first():
            return jsonify({"error": "Email already exists"}), 400

        user = User(
            username=username,
            email=email,
            password_hash=generate_password_hash(password),
            last_login_ip=None
        )
        db.session.add(user)
        db.session.commit()

        increment_registration_ip(ip)
        log_security("register_success", ip=ip, user_id=user.id)

        return jsonify({
            "message": "User created successfully",
            "user_id": user.id,
            "username": user.username
        }), 201

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/login', methods=['POST', 'OPTIONS'])
def login():
    if request.method == 'OPTIONS':
        return '', 200

    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400

        username = (data.get('username') or '').strip()
        password = (data.get('password') or '')

        ip = get_real_ip()
        if is_ip_blocked(ip):
            log_security("login_blocked_ip", ip=ip, details=f"username={username}")
            return jsonify({"error": "IP blocked"}), 429

        if check_login_bruteforce(ip):
            ban_ip(ip, reason='login_bruteforce', hours=1)
            log_security("login_bruteforce_block", ip=ip, details=f"username={username}")
            return jsonify({"error": "Too many failed attempts, IP temporarily blocked"}), 429

        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            user.last_login_ip = ip
            db.session.commit()

            record_login_attempt(ip, username, True)
            log_security("login_success", ip=ip, user_id=user.id)

            return jsonify({"success": True, "user_id": user.id, "username": user.username}), 200

        record_login_attempt(ip, username, False)
        log_security("login_failed", ip=ip, details=f"username={username}")
        return jsonify({"error": "Invalid credentials"}), 401

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ==============================
#            ПРОФИЛЬ
# ==============================

@app.route('/api/user/<int:user_id>/profile', methods=['GET', 'OPTIONS'])
def get_user_profile(user_id):
    if request.method == 'OPTIONS':
        return '', 200

    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({"error": "User not found"}), 404

        profile = UserProfile.query.filter_by(user_id=user_id).first()
        if not profile:
            profile = UserProfile(user_id=user_id)
            db.session.add(profile)
            db.session.commit()

        return jsonify({
            "user_id": user.id,
            "username": user.username,
            "avatar": profile.avatar,
            "description": profile.description,
            "created_at": user.created_at.strftime('%Y-%m-%d'),
            "is_premium": profile.is_premium,
            "premium_until": profile.premium_until.strftime('%Y-%m-%d') if profile.premium_until else None
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/user/<int:user_id>/profile', methods=['PUT', 'OPTIONS'])
def update_user_profile(user_id):
    if request.method == 'OPTIONS':
        return '', 200

    try:
        data = request.get_json()
        if not data:
            return jsonify({"error": "No data provided"}), 400

        profile = UserProfile.query.filter_by(user_id=user_id).first()
        if not profile:
            profile = UserProfile(user_id=user_id)
            db.session.add(profile)

        if 'avatar' in data and data['avatar'] in AVAILABLE_AVATARS:
            profile.avatar = data['avatar']

        if 'description' in data:
            if len(data['description']) > 200:
                return jsonify({"error": "Description too long"}), 400
            profile.description = data['description']

        db.session.commit()
        return jsonify({"success": True, "message": "Profile updated successfully"})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/avatars', methods=['GET', 'OPTIONS'])
def get_avatars():
    if request.method == 'OPTIONS':
        return '', 200
    return jsonify(AVAILABLE_AVATARS)

@app.route('/html/avatars/<path:filename>')
def serve_avatars(filename):
    return send_from_directory('html/avatars', filename)

# ==============================
#          СТАТИСТИКА
# ==============================

@app.route('/api/stats', methods=['GET', 'OPTIONS'])
def get_stats():
    if request.method == 'OPTIONS':
        return '', 200
    try:
        total_downloads = Download.query.count()
        total_users = User.query.count()
        total_reviews = Review.query.count()
        return jsonify({
            "total_downloads": total_downloads,
            "total_users": total_users,
            "total_reviews": total_reviews
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/html/apps/<path:filename>')
def serve_apps_files(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

# ==============================
#      TELEGRAM WEBHOOK
# ==============================
def _tg_get_updates(offset=None, timeout=30):
    if not TG_BOT_TOKEN:
        return None
    url = f"https://api.telegram.org/bot{TG_BOT_TOKEN}/getUpdates"
    payload = {"timeout": timeout}
    if offset is not None:
        payload["offset"] = offset
    try:
        r = requests.get(url, params=payload, timeout=timeout+5)
        return r.json()
    except Exception as e:
        print("getUpdates error:", e)
        return None

def _process_telegram_update(upd: dict):
    # Тут используем ту же логику, что и в telegram_webhook(),
    # только берём данные из upd напрямую
    try:
        # callback
        if "callback_query" in upd:
            cq = upd["callback_query"]
            cq_id = cq.get("id")
            from_id = int(cq.get("from", {}).get("id", 0) or 0)
            msg = cq.get("message") or {}
            chat_id = int((msg.get("chat") or {}).get("id", 0) or 0)
            message_id = int(msg.get("message_id", 0) or 0)

            data = cq.get("data") or ""
            parts = data.split("|")
            if len(parts) != 3 or parts[0] != "rep":
                tg_answer_callback(cq_id, "Неизвестная кнопка")
                return

            report_id = int(parts[1])
            action = parts[2]

            with app.app_context():
                rep = Report.query.get(report_id)
                if not rep:
                    tg_answer_callback(cq_id, "Жалоба не найдена")
                    return

                review = Review.query.get(rep.review_id)

                allowed = False
                if from_id == TG_ADMIN_ID:
                    allowed = True
                else:
                    if review:
                        app_id = int(review.app_id)
                        m = TgModerator.query.filter(
                            TgModerator.tg_user_id == from_id,
                            ((TgModerator.app_id == None) | (TgModerator.app_id == app_id))
                        ).first()
                        allowed = bool(m)

                if not allowed:
                    tg_answer_callback(cq_id, "Нет прав")
                    return

                if action == "del":
                    if review:
                        delete_review_full(review.id)
                    rep.status = "resolved"
                    rep.handled_by_tg = from_id
                    rep.handled_action = "delete"
                    db.session.commit()

                    tg_answer_callback(cq_id, "Отзыв удалён")
                    tg_edit_message(chat_id, message_id, "✅ Жалоба обработана: <b>отзыв удалён</b>", reply_markup={"inline_keyboard": []})
                    return

                if action == "banq":
                    # показываем подтверждение
                    kb2 = {
                        "inline_keyboard": [
                            [
                                {"text": "✅ Да, забанить", "callback_data": f"rep|{rep.id}|ban2"},
                                {"text": "↩️ Отмена", "callback_data": f"rep|{rep.id}|ign"}
                            ]
                        ]
                    }
                    tg_answer_callback(cq_id, "Подтвердите бан")
                    tg_edit_message(chat_id, message_id,
                                    "⚠️ <b>Вы действительно хотите забанить пользователя?</b>\n"
                                    "Это удалит пользователя и все его отзывы/комментарии.",
                                    reply_markup=kb2)
                    return "ok", 200

                if action == "ban2":
                    if review:
                        ban_user_and_purge(review.user_id)
                    rep.status = "resolved"
                    rep.handled_by_tg = from_id
                    rep.handled_action = "ban"
                    db.session.commit()

                    tg_answer_callback(cq_id, "Пользователь удалён + контент очищен")
                    tg_edit_message(chat_id, message_id,
                                    "⛔ Жалоба обработана: <b>пользователь удалён + контент очищен</b>",
                                    reply_markup={"inline_keyboard": []})
                    return "ok", 200


                if action == "ign":
                    rep.status = "ignored"
                    rep.handled_by_tg = from_id
                    rep.handled_action = "ignore"
                    db.session.commit()

                    tg_answer_callback(cq_id, "Игнорировано")
                    tg_edit_message(chat_id, message_id, "✅ Жалоба обработана: <b>игнор</b>", reply_markup={"inline_keyboard": []})
                    return

                tg_answer_callback(cq_id, "Неизвестное действие")
            return

        # commands
        if "message" in upd:
            msg = upd["message"]
            text_ = (msg.get("text") or "").strip()
            from_id = int((msg.get("from") or {}).get("id", 0) or 0)
            chat_id = int((msg.get("chat") or {}).get("id", 0) or 0)

            if not text_.startswith("/"):
                return

            if from_id != TG_ADMIN_ID:
                tg_send_message(chat_id, "Нет прав.")
                return

            with app.app_context():
                if text_.startswith("/addmod"):
                    parts = text_.split()
                    if len(parts) < 2:
                        tg_send_message(chat_id, "Использование: /addmod <tg_id> [app_id]")
                        return
                    tg_id = int(parts[1])
                    app_id = int(parts[2]) if len(parts) >= 3 else None

                    ex = TgModerator.query.filter_by(tg_user_id=tg_id, app_id=app_id).first()
                    if not ex:
                        db.session.add(TgModerator(tg_user_id=tg_id, app_id=app_id))
                        db.session.commit()

                    tg_send_message(chat_id, f"Ок. Модератор {tg_id} добавлен " + (f"для app_id={app_id}" if app_id is not None else "глобально"))
                    return

                if text_.startswith("/delmod"):
                    parts = text_.split()
                    if len(parts) < 2:
                        tg_send_message(chat_id, "Использование: /delmod <tg_id> [app_id]")
                        return
                    tg_id = int(parts[1])
                    app_id = int(parts[2]) if len(parts) >= 3 else None

                    TgModerator.query.filter_by(tg_user_id=tg_id, app_id=app_id).delete()
                    db.session.commit()

                    tg_send_message(chat_id, f"Ок. Модератор {tg_id} удалён " + (f"для app_id={app_id}" if app_id is not None else "глобально"))
                    return

                if text_.startswith("/mods"):
                    rows = TgModerator.query.order_by(TgModerator.tg_user_id.asc()).all()
                    if not rows:
                        tg_send_message(chat_id, "Модераторов нет.")
                        return
                    lines = []
                    for r in rows:
                        lines.append(f"{r.tg_user_id} — " + (f"app_id={r.app_id}" if r.app_id is not None else "global"))
                    tg_send_message(chat_id, "Модераторы:\n" + "\n".join(lines))
                    return

                tg_send_message(chat_id, "Команды: /addmod /delmod /mods")
            return

    except Exception as e:
        print("process update error:", e)

def start_telegram_polling():
    if not TG_BOT_TOKEN:
        print("[TG] TG_BOT_TOKEN is empty, polling disabled")
        return

    print("[TG] Polling started (local mode).")
    offset = None

    # чтобы не было конфликта: выключаем webhook (важно!)
    try:
        requests.post(f"https://api.telegram.org/bot{TG_BOT_TOKEN}/deleteWebhook", json={"drop_pending_updates": True}, timeout=10)
    except Exception:
        pass

    while True:
        data = _tg_get_updates(offset=offset, timeout=25)
        if not data or not data.get("ok"):
            time.sleep(2)
            continue

        results = data.get("result") or []
        for upd in results:
            offset = (upd.get("update_id") or 0) + 1
            _process_telegram_update(upd)

        time.sleep(0.2)

# ==============================
#            MIGRATIONS
# ==============================

def _table_columns(table: str) -> set[str]:
    rows = db.session.execute(text(f"PRAGMA table_info({table});")).fetchall()
    return {r[1] for r in rows}

def _table_exists(table: str) -> bool:
    row = db.session.execute(
        text("SELECT name FROM sqlite_master WHERE type='table' AND name=:t"),
        {"t": table}
    ).fetchone()
    return row is not None

def ensure_schema_migrations():
    db.create_all()

    if _table_exists("user"):
        cols = _table_columns("user")
        if "last_login_ip" not in cols:
            db.session.execute(text("ALTER TABLE user ADD COLUMN last_login_ip VARCHAR(50);"))
            db.session.commit()
            print("[MIGRATION] Added user.last_login_ip")

    if _table_exists("user_profile"):
        cols = _table_columns("user_profile")
        if "is_premium" not in cols:
            db.session.execute(text("ALTER TABLE user_profile ADD COLUMN is_premium INTEGER DEFAULT 0;"))
            db.session.commit()
            print("[MIGRATION] Added user_profile.is_premium")
        if "premium_until" not in cols:
            db.session.execute(text("ALTER TABLE user_profile ADD COLUMN premium_until DATETIME;"))
            db.session.commit()
            print("[MIGRATION] Added user_profile.premium_until")
        if "avatar" not in cols:
            db.session.execute(text("ALTER TABLE user_profile ADD COLUMN avatar VARCHAR(100) DEFAULT 'avatar1.png';"))
            db.session.commit()
            print("[MIGRATION] Added user_profile.avatar")
        if "description" not in cols:
            db.session.execute(text("ALTER TABLE user_profile ADD COLUMN description TEXT DEFAULT '';"))
            db.session.commit()
            print("[MIGRATION] Added user_profile.description")

def init_db():
    ensure_schema_migrations()

    if User.query.count() == 0:
        test_user = User(
            username="test",
            email="test@example.com",
            password_hash=generate_password_hash("test123")
        )
        db.session.add(test_user)
        db.session.commit()

if __name__ == '__main__':
    with app.app_context():
        init_db()
        print(f"Total downloads in database: {Download.query.count()}")
    t = threading.Thread(target=start_telegram_polling, daemon=True)
    t.start()
    app.run(host='0.0.0.0', port=5000, debug=False, threaded=True)