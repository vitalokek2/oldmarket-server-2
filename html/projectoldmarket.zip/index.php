<?php
require_once __DIR__ . '/auth_cookie.php';
require_once 'android_versions.php';

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$auth = auth_user();

// --- Получение приложений/топа/баннеров как у тебя ---
$apiResponse = api_get('/api/apps');
$allApps = $apiResponse ? json_decode($apiResponse, true) : [];
if (!is_array($allApps)) $allApps = [];

$apps = [];
foreach ($allApps as $app) {
    $is_game = filter_var($app['is_game'] ?? false, FILTER_VALIDATE_BOOLEAN);
    if ($is_game === false) $apps[] = $app;
}

$topAppsResponse = api_get('/api/top-apps');
$topApps = $topAppsResponse ? json_decode($topAppsResponse, true) : [];
if (!is_array($topApps)) $topApps = [];

$bannerResponse = api_get('/api/banners');
$banners = $bannerResponse ? json_decode($bannerResponse, true) : [];
if (!is_array($banners)) $banners = [];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
  <meta http-equiv="Pragma" content="no-cache" />
  <meta http-equiv="Expires" content="0" />
  <title>OldMarket</title>
  <link rel="stylesheet" href="style.css">
  <style type="text/css">
    body { margin:0; background:#5a5a5a; }
    .page-shell { width:100%; }
    .page-center { width:96%; max-width:1180px; margin:0 auto; }
    .desktop-view .page-center { max-width:1200px; }
    .mobile-view .page-center { width:100%; max-width:none; }
    .mobile-view .topnav,
    .mobile-view .search-container,
    .mobile-view .app-list,
    .mobile-view .featured,
    .mobile-view .footer { width:auto; margin-left:8px; margin-right:8px; }
    .mobile-view .logo img { width:180px; height:auto; }
    .mobile-view .topnav { height:auto; padding-top:8px; padding-bottom:8px; }
    .mobile-view .user-section { float:none; display:block; margin-top:8px; text-align:left; }
    .mobile-view .app { width:auto; display:block; }
    .mobile-view .add { display:block; text-align:center; }
    .mobile-view .button-image { max-width:95%; height:auto; }
    .desktop-view .app-list { overflow:hidden; }
    .desktop-view .app { float:left; width:46%; margin:8px 2%; }
    .desktop-view .add { float:left; width:46%; margin:8px 2%; text-align:center; }
    .desktop-view .app:after, .desktop-view .app-list:after, .topnav:after { content:""; display:block; clear:both; }
    .classic-banner { background:#2f2f2f; border:1px solid #888; padding:6px; margin:10px auto; }
    .desktop-view .classic-banner { max-width:1180px; }
    .mobile-view .classic-banner { margin-left:8px; margin-right:8px; }
  </style>
</head>
<body class="desktop-view">
  <div class="page-shell">
    <div class="sticky-header-section">
      <div class="page-center">
        <header class="topnav">
          <div class="logo">
            <img src="logo.png" alt="Android Market Logo" width="260">
            <p id="visitorCount" style="color: rgb(224, 224, 224); font-size: 0.8em;"></p>
          </div>

          <div class="user-section">
            <?php if ($auth): ?>
              <a href="profile.php" style="color: white; text-decoration: none; display: flex; align-items: center; gap: 8px;">
                <img src="<?= API_BASE ?>/html/avatars/<?= htmlspecialchars($auth['avatar'] ?? 'default_avatar.png') ?>"
                     width="25" height="25" style="border-radius: 50%;">
                <div>
                  <div class="<?= ($auth['is_premium'] ?? 0) ? 'premium-user' : '' ?>">
                    <?= htmlspecialchars($auth['username'] ?? '') ?>
                  </div>
                </div>
              </a>
              <a href="logout.php" style="color: white; margin-left: 10px;">Выйти</a>
            <?php else: ?>
              <a href="login.php" style="color: white;">Войти</a>
              <a href="register.php" style="color: white; margin-left: 10px;">Регистрация</a>
            <?php endif; ?>
          </div>
        </header>

        <div class="search-container">
          <input type="text" id="searchInput" placeholder="Поиск" onkeyup="searchApps()">
        </div>
      </div>
    </div>

    <div class="page-center classic-banner">
      <div class="banner" id="banner" data-interval="5000" style="width:100%; text-align:center; overflow:hidden; cursor:pointer;">
        <?php if (!empty($banners)): ?>
          <a id="bannerLink" href="<?= htmlspecialchars($banners[0]['url'] ?? '') ?>" target="_blank" rel="noopener">
            <img id="bannerImg" src="http://oldmarket.store:5000/html/banners/<?= htmlspecialchars($banners[0]['image']) ?>" alt="Баннер" style="max-width:100%; width:100%; height:auto; border:0;">
          </a>
        <?php else: ?>
          <img id="bannerImg" src="banner1.jpg" alt="Баннер" style="max-width:100%; width:100%; height:auto; border:0;">
        <?php endif; ?>
      </div>
    </div>

    <div class="page-center">
      <main>
        <section class="featured">
          <h2 style="color: white; text-align: center;">Популярные приложения</h2>
          <div class="app-list">
            <?php foreach ($topApps as $app): ?>
              <div class="app" onclick="installApp(<?= $app['id'] ?>)">
                <img src="http://oldmarket.store:5000/html/apps/<?= $app['icon'] ?>" width="55">
                <div class="app-info">
                  <span class="app-title"><?= htmlspecialchars($app['name']) ?></span><br>
                  <span>Рейтинг: <?= $app['rating'] ?> ★</span><br>
                  <span>Скачиваний: <?= $app['downloads'] ?></span><br>
                  <span>Android <?= apiToAndroidVersion($app['api']) ?></span>
                </div>
              </div>
            <?php endforeach; ?>
          </div>

          <h2 style="color: white; text-align: center; margin-top: 30px;">Все приложения</h2>
          <div class="app-list" id="allAppsList">
            <div class="add">
              <img src="games.png" alt="Игры" width="190" class="button-image" onclick="window.location.href='games.php'">
            </div>
            <div class="add">
              <img src="downloadmarket.jpg" alt="Скачать маркет" width="190" class="button-image" onclick="window.location.href='marketdownload.html'">
            </div>

            <?php foreach ($apps as $app): ?>
              <div class="app" onclick="installApp(<?= $app['id'] ?>)">
                <img src="http://oldmarket.store:5000/html/apps/<?= $app['icon'] ?>" width="55">
                <div class="app-info">
                  <span class="app-title"><?= htmlspecialchars($app['name']) ?></span><br>
                  <span>Рейтинг: <?= $app['rating'] ?> ★</span><br>
                  <span>Скачиваний: <?= $app['downloads'] ?></span><br>
                  <span>Android <?= apiToAndroidVersion($app['api']) ?></span>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        </section>
      </main>
    </div>

    <div class="page-center">
      <div class="footer">
        <p>OldMarket &copy; 2025-2026</p>
      </div>
    </div>
  </div>

  <script type="text/javascript">
    var BANNERS = <?php echo json_encode($banners, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
    var API_BASE_URL = 'http://oldmarket.store:5000';
    var searchTimer = null;
    var initialAllAppsHTML = null;
    var buttonsHTML = null;

    function onReady(fn) {
      if (document.readyState === 'complete' || document.readyState === 'interactive') {
        setTimeout(fn, 0);
      } else if (document.addEventListener) {
        document.addEventListener('DOMContentLoaded', fn, false);
      } else if (document.attachEvent) {
        document.attachEvent('onreadystatechange', function () {
          if (document.readyState === 'complete') { fn(); }
        });
      }
    }

    function getViewportWidth() {
      if (typeof window.innerWidth !== 'undefined') return window.innerWidth;
      if (document.documentElement && document.documentElement.clientWidth) return document.documentElement.clientWidth;
      if (document.body && document.body.clientWidth) return document.body.clientWidth;
      return 1024;
    }

    function applyResponsiveMode() {
      var body = document.body || document.getElementsByTagName('body')[0];
      if (!body) return;
      var w = getViewportWidth();
      body.className = body.className.replace(/\bmobile-view\b/g, '').replace(/\bdesktop-view\b/g, '').replace(/^\s+|\s+$/g, '');
      if (w <= 760) {
        body.className += (body.className ? ' ' : '') + 'mobile-view';
      } else {
        body.className += (body.className ? ' ' : '') + 'desktop-view';
      }
    }

    function installApp(appId) {
      window.location.href = 'app.php?id=' + appId;
    }

    function _escapeHtml(str) {
      str = (str === null || typeof str === 'undefined') ? '' : String(str);
      str = str.replace(/&/g, '&amp;');
      str = str.replace(/</g, '&lt;');
      str = str.replace(/>/g, '&gt;');
      str = str.replace(/"/g, '&quot;');
      str = str.replace(/'/g, '&#039;');
      return str;
    }

    function _renderEmpty(listEl) {
      listEl.innerHTML = (buttonsHTML || '') + '<div style="color:white; text-align:center; width:100%; padding:16px;">Ничего не найдено</div>';
    }

    function saveInitialList() {
      var listEl = document.getElementById('allAppsList');
      var adds, i, html;
      if (!listEl || initialAllAppsHTML !== null) return;
      initialAllAppsHTML = listEl.innerHTML;
      adds = listEl.getElementsByTagName('div');
      html = '';
      for (i = 0; i < adds.length; i++) {
        if ((' ' + adds[i].className + ' ').indexOf(' add ') !== -1) {
          html += adds[i].outerHTML ? adds[i].outerHTML : '';
        }
      }
      buttonsHTML = html;
    }

    function buildAppItem(app) {
      var item = document.createElement('div');
      var id = app && app.id ? app.id : 0;
      var name = _escapeHtml(app && app.name ? app.name : '');
      var icon = _escapeHtml(app && app.icon ? app.icon : '');
      var rating = _escapeHtml(app && typeof app.rating !== 'undefined' ? app.rating : 0);
      var downloads = _escapeHtml(app && typeof app.downloads !== 'undefined' ? app.downloads : 0);
      var apiLevel = _escapeHtml(app && typeof app.api !== 'undefined' ? app.api : '');
      item.className = 'app';
      item.onclick = function() { installApp(id); };
      item.innerHTML = ''
        + '<img src="' + API_BASE_URL + '/html/apps/' + icon + '" width="55">'
        + '<div class="app-info">'
        + '<span class="app-title">' + name + '</span><br>'
        + '<span>Рейтинг: ' + rating + ' ★</span><br>'
        + '<span>Скачиваний: ' + downloads + '</span><br>'
        + '<span>Android API ' + apiLevel + '</span>'
        + '</div>';
      return item;
    }

    function doSearchRequest(q) {
      var listEl = document.getElementById('allAppsList');
      var xhr, url;
      if (!listEl) return;
      url = API_BASE_URL + '/api/apps/search?q=' + encodeURIComponent(q) + '&is_game=0&limit=200&offset=0';
      xhr = new XMLHttpRequest();
      xhr.open('GET', url, true);
      if (xhr.setRequestHeader) xhr.setRequestHeader('Cache-Control', 'no-cache');
      xhr.onreadystatechange = function() {
        var data, i;
        if (xhr.readyState !== 4) return;
        if (xhr.status < 200 || xhr.status >= 300) {
          listEl.innerHTML = initialAllAppsHTML !== null ? initialAllAppsHTML : listEl.innerHTML;
          return;
        }
        try {
          data = JSON.parse(xhr.responseText);
        } catch (e) {
          data = null;
        }
        if (!data || typeof data.length === 'undefined') {
          listEl.innerHTML = initialAllAppsHTML !== null ? initialAllAppsHTML : listEl.innerHTML;
          return;
        }
        listEl.innerHTML = buttonsHTML || '';
        if (data.length === 0) {
          _renderEmpty(listEl);
          return;
        }
        for (i = 0; i < data.length; i++) {
          listEl.appendChild(buildAppItem(data[i]));
        }
      };
      xhr.send(null);
    }

    function searchApps() {
      var input = document.getElementById('searchInput');
      var listEl = document.getElementById('allAppsList');
      var q;
      if (!input || !listEl) return;
      saveInitialList();
      q = input.value;
      q = q ? q.replace(/^\s+|\s+$/g, '') : '';
      if (!q) {
        listEl.innerHTML = initialAllAppsHTML;
        return;
      }
      if (searchTimer) clearTimeout(searchTimer);
      searchTimer = setTimeout(function() {
        doSearchRequest(q);
      }, 250);
    }

    onReady(function () {
      var imgEl, linkEl, changeMs, bannerWrap, intervalAttr, tmp, i, im, idx;
      applyResponsiveMode();
      if (window.addEventListener) {
        window.addEventListener('resize', applyResponsiveMode, false);
      } else if (window.attachEvent) {
        window.attachEvent('onresize', applyResponsiveMode);
      }
      saveInitialList();

      if (!BANNERS || !BANNERS.length) return;
      imgEl = document.getElementById('bannerImg');
      linkEl = document.getElementById('bannerLink');
      if (!imgEl) return;
      changeMs = 5000;
      bannerWrap = document.getElementById('banner');
      if (bannerWrap) {
        intervalAttr = bannerWrap.getAttribute('data-interval');
        tmp = parseInt(intervalAttr, 10);
        if (!isNaN(tmp) && tmp > 0) changeMs = tmp;
      }
      for (i = 0; i < BANNERS.length; i++) {
        if (BANNERS[i] && BANNERS[i].image) {
          im = new Image();
          im.src = API_BASE_URL + '/html/banners/' + BANNERS[i].image;
        }
      }
      idx = 0;
      function applyBanner(i) {
        var b = BANNERS[i] || {};
        var src = API_BASE_URL + '/html/banners/' + (b.image || '');
        var url = b.url || '';
        imgEl.src = src;
        if (linkEl) {
          url = url.replace(/^\s+|\s+$/g, '');
          if (url) {
            linkEl.href = url;
            linkEl.style.pointerEvents = 'auto';
          } else {
            linkEl.href = '#';
            linkEl.style.pointerEvents = 'none';
          }
        }
      }
      applyBanner(idx);
      setInterval(function () {
        if (BANNERS.length < 2) return;
        idx = (idx + 1) % BANNERS.length;
        applyBanner(idx);
      }, changeMs);
    });
  </script>
</body>
</html>
