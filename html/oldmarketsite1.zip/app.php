<?php
// Функция для работы с текстовыми счетчиками
function update_counter($type, $app_id = null) {
    $dir = 'counters/';
    if (!file_exists($dir)) mkdir($dir, 0777, true);
    
    if ($type === 'download') {
        $downloads_dir = $dir . 'downloads/';
        if (!file_exists($downloads_dir)) mkdir($downloads_dir, 0777, true);
        
        $file = $downloads_dir . $app_id . '.txt';
        $count = file_exists($file) ? (int)file_get_contents($file) : 0;
        
        if (isset($_GET['download'])) {
            $count++;
            file_put_contents($file, $count);
            header("Location: http://45.137.188.68:5000/api/download/$app_id");
            exit;
        }
        
        return $count;
    }
    return 0;
}

$app_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Получаем данные о приложении
$app_data = json_decode(file_get_contents("http://45.137.188.68:5000/api/app/$app_id"), true);

if (!$app_data || isset($app_data['error'])) {
    header("HTTP/1.0 404 Not Found");
    die('Приложение не найдено');
}

// Получаем количество загрузок
$download_count = update_counter('download', $app_id);

// Обработка отправки отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_review'])) {
    $review = [
        'id' => uniqid(),
        'app_id' => $app_id,
        'author' => htmlspecialchars($_POST['author']),
        'rating' => (int)$_POST['rating'],
        'text' => htmlspecialchars($_POST['text']),
        'date' => date('d.m.Y H:i')
    ];
    
    // Сохраняем отзыв в файл
    $reviews_dir = 'reviews/data/';
    if (!file_exists($reviews_dir)) {
        mkdir($reviews_dir, 0777, true);
    }
    
    file_put_contents($reviews_dir.$app_id.'_'.$review['id'].'.json', json_encode($review));
}

// Загрузка отзывов для этого приложения
$reviews = [];
$review_files = glob('reviews/data/'.$app_id.'_*.json');
foreach ($review_files as $file) {
    $reviews[] = json_decode(file_get_contents($file), true);
}

// Сортировка отзывов по дате (новые сначала)
usort($reviews, function($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});

// Расчет среднего рейтинга
$total_rating = 0;
foreach ($reviews as $review) {
    $total_rating += $review['rating'];
}
$average_rating = count($reviews) > 0 ? round($total_rating / count($reviews), 1) : 0;

// Получаем размер файла через заголовки HTTP
function get_remote_file_size($url) {
    $headers = @get_headers($url, 1);
    if ($headers && isset($headers['Content-Length'])) {
        return (int)$headers['Content-Length'];
    }
    return 0;
}
function get_download_count($app_id) {
    $file = 'counters/downloads/' . $app_id . '.txt';
    return file_exists($file) ? (int)file_get_contents($file) : 0;
}

$file_size = get_remote_file_size("http://45.137.188.68:5000/api/download/$app_id");
$file_size_mb = $file_size > 0 ? round($file_size / 1024 / 1024, 1) . ' MB' : '? MB';
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($app_data['name']); ?> - OldMarket</title>
    <link rel="stylesheet" href="css/style.css" type="text/css" />
    <!--[if IE]>
    <link rel="stylesheet" href="css/ie2.css" type="text/css" />
    <![endif]-->
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="OldMarket" />
        </div>
        <div class="search-box">
            <form action="index.php" method="get">
                <input type="text" name="search" placeholder="Поиск приложений..." />
                <button type="submit">Поиск</button>
            </form>
        </div>
    </div>
    
    <div class="main-container">
        <div class="sidebar">
            <ul class="categories">
                <li><a href="index.php">Все</a></li>
                <li><a href="index.php?category=apps">Приложения</a></li>
                <li><a href="index.php?category=games">Игры</a></li>
                <li><a href="about.php">О нас</a></li>
            </ul>
        </div>
        
        <div class="content app-page">
            <div class="app-header">
                <div class="app-icon-large">
                    <img src="http://45.137.188.68:5000/html/apps/<?php echo htmlspecialchars($app_data['icon']); ?>" alt="<?php echo htmlspecialchars($app_data['name']); ?>" />
                </div>
                <div class="app-title">
                    <h1><?php echo htmlspecialchars($app_data['name']); ?></h1>
                    <p class="developer">Разработчик: <?php echo htmlspecialchars($app_data['package']); ?></p>
                    <div class="rating">
                        <span class="stars"><?php echo str_repeat('★', round($average_rating)); ?><?php echo str_repeat('☆', 5 - round($average_rating)); ?></span>
                        <span class="average"><?php echo $average_rating; ?> (<?php echo count($reviews); ?> отзывов)</span>
                    </div>
                    <a href="app.php?id=<?php echo $app_id; ?>&download=1" class="download-btn">Скачать (<?php echo $file_size_mb; ?>)</a>
                    <span class="download-count"><?php echo $download_count; ?> загрузок</span>
                </div>
            </div>
            
            <div class="app-details">
                <h3>Описание</h3>
                <p><?php echo nl2br(htmlspecialchars($app_data['description'])); ?></p>
                
                <div class="app-specs">
                    <h3>Характеристики</h3>
                    <ul>
                        <li><strong>Версия:</strong> <?php echo htmlspecialchars($app_data['version']); ?></li>
                        <li><strong>API:</strong> <?php echo htmlspecialchars($app_data['api']); ?>+</li>
                        <li><strong>Пакет:</strong> <?php echo htmlspecialchars($app_data['package']); ?></li>
                        <li><strong>Тип:</strong> <?php echo $app_data['is_game'] ? 'Игра' : 'Приложение'; ?></li>
                    </ul>
                </div>
            </div>
            
            <div class="app-reviews">
                <h3>Отзывы (<?php echo count($reviews); ?>)</h3>
                
                <div class="add-review">
                    <h4>Добавить отзыв</h4>
                    <form method="post">
                        <div class="form-group">
                            <label for="author">Ваше имя:</label>
                            <input type="text" id="author" name="author" required />
                        </div>
                        <div class="form-group">
                            <label for="rating">Оценка:</label>
                            <select id="rating" name="rating" required>
                                <option value="5">★★★★★</option>
                                <option value="4">★★★★☆</option>
                                <option value="3">★★★☆☆</option>
                                <option value="2">★★☆☆☆</option>
                                <option value="1">★☆☆☆☆</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="text">Отзыв:</label>
                            <textarea id="text" name="text" required></textarea>
                        </div>
                        <button type="submit" name="submit_review">Отправить</button>
                    </form>
                </div>
                
                <div class="reviews-list">
                    <?php foreach ($reviews as $review): ?>
                    <div class="review">
                        <div class="review-header">
                            <span class="author"><?php echo htmlspecialchars($review['author']); ?></span>
                            <span class="date"><?php echo htmlspecialchars($review['date']); ?></span>
                            <span class="stars"><?php echo str_repeat('★', $review['rating']); ?><?php echo str_repeat('☆', 5 - $review['rating']); ?></span>
                        </div>
                        <div class="review-text">
                            <?php echo nl2br(htmlspecialchars($review['text'])); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    
                    <?php if (empty($reviews)): ?>
                    <p>Пока нет отзывов. Будьте первым!</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer">
        <p>OldMarket © 2023 - Магазин приложений в стиле Android Market 2010</p>
    </div>
</body>
</html>