<?php
// Функция для работы с текстовыми счетчиками
function update_counter($type, $app_id = null) {
    $dir = 'counters/';
    if (!file_exists($dir)) mkdir($dir, 0777, true);
    
    if ($type === 'visit') {
        $file = $dir . 'visitors.txt';
        $count = file_exists($file) ? (int)file_get_contents($file) : 0;
        
        // Учитываем только уникальных посетителей
        if (!isset($_COOKIE['oldmarket_visitor'])) {
            setcookie('oldmarket_visitor', '1', time()+3600*24);
            $count++;
            file_put_contents($file, $count);
        }
        
        return $count;
    }
    elseif ($type === 'download') {
        $downloads_dir = $dir . 'downloads/';
        if (!file_exists($downloads_dir)) mkdir($downloads_dir, 0777, true);
        
        $file = $downloads_dir . $app_id . '.txt';
        $count = file_exists($file) ? (int)file_get_contents($file) : 0;
        return $count;
    }
}

// Получаем количество посетителей
$visitors = update_counter('visit');

// Получаем общее количество загрузок
$total_downloads = 0;
$downloads_dir = 'counters/downloads/';
if (file_exists($downloads_dir)) {
    foreach (glob($downloads_dir . '*.txt') as $file) {
        $total_downloads += (int)file_get_contents($file);
    }
}

// Получаем список приложений с API
$apps = json_decode(file_get_contents('http://45.137.188.68:5000/api/apps'), true);

// Фильтрация по категориям
$category = isset($_GET['category']) ? $_GET['category'] : 'all';
$search_query = isset($_GET['search']) ? strtolower($_GET['search']) : '';

if ($search_query) {
    $apps = array_filter($apps, function($app) use ($search_query) {
        return strpos(strtolower($app['name']), $search_query) !== false || 
               strpos(strtolower($app['description']), $search_query) !== false;
    });
}

if ($category !== 'all') {
    $is_game = ($category === 'games');
    $apps = array_filter($apps, function($app) use ($is_game) {
        return $app['is_game'] === $is_game;
    });
}
if ($category === 'popular') {
    // Получаем количество скачиваний для каждого приложения
    $apps_with_downloads = array_map(function($app) {
        $download_file = 'counters/downloads/' . $app['id'] . '.txt';
        $app['downloads'] = file_exists($download_file) ? (int)file_get_contents($download_file) : 0;
        return $app;
    }, $apps);
    
    // Сортируем по количеству скачиваний (по убыванию)
    usort($apps_with_downloads, function($a, $b) {
        return $b['downloads'] - $a['downloads'];
    });
    
    $apps = $apps_with_downloads;
}

$total_apps = count($apps);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OldMarket - Магазин приложений в стиле 2010</title>
    <link rel="stylesheet" href="css/style.css" type="text/css" />
    <!--[if IE]>
    <link rel="stylesheet" href="css/ie2.css" type="text/css" />
    <![endif]-->
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="OldMarket" />
            <span class="counter">
                Онлайн: <?php echo $visitors; ?> | 
                Всего загрузок: <?php echo $total_downloads; ?>
            </span>
        </div>
        <div class="search-box">
            <form action="" method="get">
                <input type="text" name="search" placeholder="Поиск приложений..." />
                <button type="submit">Поиск</button>
            </form>
        </div>
    </div>
    
    <div class="main-container">
        <div class="sidebar">
            <ul class="categories">
                <li <?php echo $category == 'all' ? 'class="active"' : ''; ?>>
                    <a href="?category=all">Все</a>
                </li>
                <li <?php echo $category == 'apps' ? 'class="active"' : ''; ?>>
                    <a href="?category=apps">Приложения</a>
                </li>
                <li <?php echo $category == 'games' ? 'class="active"' : ''; ?>>
                    <a href="?category=games">Игры</a>
                </li>
                <li <?php echo $category == 'popular' ? 'class="active"' : ''; ?>>
                    <a href="?category=popular">Популярные</a>
                </li>
                <li>
                    <a href="about.php">О нас</a>
                </li>
            </ul>
        </div>
        
        <div class="content">
            <h2><?php 
                if ($search_query) {
                    echo "Результаты поиска: '".htmlspecialchars($_GET['search'])."'";
                } else {
                    switch ($category) {
                        case 'all':
                            echo 'Все приложения';
                            break;
                        case 'apps':
                            echo 'Приложения';
                            break;
                        case 'games':
                            echo 'Игры';
                            break;
                        case 'popular':
                            echo 'Популярные приложения';
                            break;
                        default:
                            echo 'Приложения';
                    }
                }
            ?></h2>
            
            <div class="app-grid">
                <?php foreach ($apps as $app): ?>
                <div class="app-card">
                    <div class="app-icon">
                        <img src="http://45.137.188.68:5000/html/apps/<?php echo $app['icon']; ?>" alt="<?php echo $app['name']; ?>" />
                    </div>
                    <div class="app-info">
                        <h3><a href="app.php?id=<?php echo $app['id']; ?>"><?php echo $app['name']; ?></a></h3>
                        <p class="version">Версия: <?php echo $app['version']; ?></p>
                        <p class="description"><?php echo substr($app['description'], 0, 100).'...'; ?></p>
                        <a href="app.php?id=<?php echo $app['id']; ?>" class="details-btn">Подробнее</a>
                        <span class="download-count"><?php echo update_counter('download', $app['id']); ?> загрузок</span>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <div class="footer">
        <p>OldMarket © 2023 - Магазин приложений в стиле Android Market 2010</p>
    </div>
</body>
</html>