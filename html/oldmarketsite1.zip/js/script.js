// Функция для загрузки отзывов через AJAX (для современных браузеров)
document.addEventListener('DOMContentLoaded', function() {
    // Инициализация для IE5+
    if (window.XMLHttpRequest) {
        // Можно добавить AJAX-функциональность для современных браузеров
    }
    
    // Анимация кнопок (для браузеров с поддержкой CSS3)
    var buttons = document.querySelectorAll('button, .details-btn, .download-btn');
    buttons.forEach(function(button) {
        button.addEventListener('mousedown', function() {
            this.style.transform = 'translateY(1px)';
        });
        button.addEventListener('mouseup', function() {
            this.style.transform = 'translateY(0)';
        });
        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});