<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>О нас - OldMarket</title>
    <link rel="stylesheet" href="css/style.css" type="text/css" />
    <!--[if IE]>
    <link rel="stylesheet" href="css/ie2.css" type="text/css" />
    <![endif]-->
</head>
<body>
    <div class="header">
        <div class="logo">
            <img src="images/logo.png" alt="OldMarket" />
        </div>
        <div class="search-box">
            <form action="index.php" method="get">
                <input type="text" name="search" placeholder="Поиск приложений..." />
                <button type="submit">Поиск</button>
            </form>
        </div>
    </div>
    
    <div class="main-container">
        <div class="sidebar">
            <ul class="categories">
                <li><a href="index.php">Все</a></li>
                <li><a href="index.php?category=apps">Приложения</a></li>
                <li><a href="index.php?category=games">Игры</a></li>
                <li class="active"><a href="about.php">О нас</a></li>
            </ul>
        </div>
        
        <div class="content">
            <h2>Об OldMarket</h2>
            
            <div class="about-content">
                <div class="about-section">
                    <p>OldMarket - магазин приложений для старых Android устройств</p>
                    <h3>Предложка приложений:</h3>
                    <p>Email: oldmarket2025@gmail.com</p>
                    <h3>Источники:</h3>
                    <p>Telegram Канал: <a href="https://t.me/apksherr" style="color: #0066cc; text-decoration: none;">t.me/apksherr</a></p>
                    <p>TikTok: <a href="https://www.tiktok.com/@oldandroider" style="color: #0066cc; text-decoration: none;">www.tiktok.com/@oldandroider</a></p>
                    <p>YouTube: <a href="https://youtube.com/@oldandroider" style="color: #0066cc; text-decoration: none;">youtube.com/@oldandroider</a></p>
                    <p>OpenVK: <a href="https://ovk.to/id21946" style="color: #0066cc; text-decoration: none;">ovk.to/id21946</a></p>
                    <p>Поддержать проект: <a href="https://www.donationalerts.com/r/vasiliy_telelom" style="color: #0066cc; text-decoration: none;">www.donationalerts.com/r/vasiliy_telelom</a></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="footer">
        <p>OldMarket © 2025</p>
    </div>
</body>
</html>